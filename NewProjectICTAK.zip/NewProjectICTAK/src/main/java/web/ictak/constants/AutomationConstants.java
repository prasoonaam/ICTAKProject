package web.ictak.constants;

import web.ictak.pages.EventsTachlon;

public class AutomationConstants {
	// Navigation
	
	  public static String Homeurl="http://64.227.132.109/LandingPage";
	  public static String AboutUsurl="http://64.227.132.109/LandingPage/about";
	  public static String Coursesurl="http://64.227.132.109/LandingPage/courses";
	  public static String Membershipurl="http://64.227.132.109/LandingPage/membership";
	  public static String Eventsurl="http://64.227.132.109/LandingPage/events";
	  public static String ContactUsurl ="http://64.227.132.109/LandingPage/contactus";
	  public static String Corporatemembershipurl="http://64.227.132.109/LandingPage/corporate";
	  
//	   expected navigation
	  
	  public static String expAboutUsurl="http://64.227.132.109/LandingPage/about";
	  public static String expCoursesurl="http://64.227.132.109/LandingPage/courses";
	  public static String expContactUsurl ="http://64.227.132.109/LandingPage/contactus";
// Login
	  public static String warningMsg1="Warning!!";
	  public static String warningMsg2="Invalid!";

	  public static String exp_uname_err_msg="Username Required";
	  public static String exp_psswd_err_msg="Password Required";
	//Events Tachlon
		public static EventsTachlon events=null;
		public static String events_Url="http://64.227.132.109/LandingPage/event/61d88e9322c79c40406009eb";


}
