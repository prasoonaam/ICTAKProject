package web.ictak.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import web.ictak.constants.AutomationConstants;

public class LoginCorporateMembership{
    WebDriver driver;
@FindBy(xpath="//a[@routerlink='/adminpage/corporate']") 
WebElement logCorp;
@FindBy(xpath="//button[contains(text(),'Download')]") 
WebElement Corpdwd;
public LoginCorporateMembership(WebDriver driver){

        // TODO Auto-generated constructor stub
        this.driver=driver;
        PageFactory.initElements(driver, this);
    }
	public void Logincorporate()

	{			

		logCorp.click();

	}
	public void Corporatedownload()

	{
		Corpdwd.click();

	}
	
	
}
