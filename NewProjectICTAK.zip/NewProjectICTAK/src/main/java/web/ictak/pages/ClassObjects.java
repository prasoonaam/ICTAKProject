//package web.ictak.pages;
//import web.ictak.pages.ContactUs;
//import web.ictak.pages.CorporateMembershipDownload;
////import org.ictakwebsite.pages.CorporateMembershipDownload;
//import web.ictak.pages.Events;
//import org.ictakwebsite.pages.Pages;
//import web.ictak.pages.SuperAdminLogin;
//public class ClassObjects {
//	//public static EventsICSET EventsICSET;
//
//	
//	
//    public static Pages page=null;
//	public static EventsICSET events=null;
//	public static CorporateMembershipDownload corpmembershipdownload=null;
//	public static SuperAdminLogin admin=null;
//	public static ContactUs contactus=null;
//
//
//	
//}
