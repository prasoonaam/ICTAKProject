package web.ictak.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

	public class LoginCourseRegistration{
	    WebDriver driver;
	@FindBy(xpath="//a[@routerlink='/adminpage/registered-users']") 
	WebElement logCourseReg;
	@FindBy(xpath="//button[@target='_blank']") 
	WebElement Courseregdwd;
	public LoginCourseRegistration(WebDriver driver){

	        // TODO Auto-generated constructor stub
	        this.driver=driver;
	        PageFactory.initElements(driver, this);
	    }
	public void LogincourseReg()

	{			

		logCourseReg.click();

	}
	public void Courseregdownload()

	{
		Courseregdwd.click();

	}

}
