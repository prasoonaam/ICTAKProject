package web.ictak.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import web.ictak.constants.AutomationConstants;

public class LoginPartnership{
    WebDriver driver;
@FindBy(xpath="//a[@routerlink='/adminpage/partnership']") 
WebElement logPart;
@FindBy(xpath="//button[@target='_blank']") 
WebElement Partdwd;
@FindBy(xpath="//a[@aria-controls='ProfileNav']") 
WebElement navctrl;
@FindBy(xpath="//div[@id='ProfileNav']//child::a") 
WebElement logout;
public LoginPartnership(WebDriver driver){

        // TODO Auto-generated constructor stub
        this.driver=driver;
        PageFactory.initElements(driver, this);
    }
	public void Loginpartnership()

	{			
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(30));
		wait.until(ExpectedConditions.visibilityOf(logPart));	
		logPart.click();

	}
	public void Partnershipdownload()

	{
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(30));
		wait.until(ExpectedConditions.visibilityOf(Partdwd));	
		Partdwd.click();

	}
	public void NavCtrl()

	{
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(30));
		wait.until(ExpectedConditions.visibilityOf(navctrl));
		navctrl.click();

	}
	public void Logout()

	{
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(30));
		wait.until(ExpectedConditions.visibilityOf(logout));	
		logout.click();

	}
}
