package web.ictak.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import web.ictak.constants.AutomationConstants;

public class CorporateMembershipForm{
    WebDriver driver;
@FindBy(xpath="//a[contains(text(),' Memberships ')]") 
WebElement corpform;
@FindBy(xpath="//h6[contains(text(),' Corporate Membership ')]") 
WebElement corpfound;
@FindBy(xpath="//button[text()='Register Here']") 
WebElement reghere;
@FindBy(xpath="//input[@type='text'and@name='name']")
WebElement name;

@FindBy(xpath="//input[@type='text'and@name='address']")
WebElement add;

@FindBy(xpath="//input[@type='text'and@name='head']")
WebElement head;

@FindBy(xpath="//input[@type='text'and@name='nature']")
WebElement nature;

@FindBy(xpath="//input[@type='text'and@name='website']")
WebElement web;

@FindBy(xpath="//input[@type='text'and@name='identityNo']")
WebElement cin;

@FindBy(xpath="//input[@type='text'and@name='GST']")
WebElement gst;

@FindBy(xpath="//input[@name='nameofContact']")
WebElement Pocname;
@FindBy(xpath="//label[contains(text(),'Mobile Number')]//parent::Div//following-sibling::Div//child::input")
WebElement mobnum;

@FindBy(xpath="//input[@type='text'and @name='TechnicalSkill']")
WebElement techskill;

@FindBy(xpath="//input[@type='text'and @formcontrolname='email' ]")
WebElement email;

@FindBy(xpath="//input[@type='text'and @name='employeeCount' ]")
WebElement empcount;

@FindBy(xpath="//span[@class='ng-arrow-wrapper']")
WebElement collaborate;

@FindBy(xpath="//span[text()='Fresher hiring']")
WebElement Fresherhiring;

@FindBy(xpath="//input[@formcontrolname='details']")
WebElement activitydetails;

@FindBy(xpath="input#flexSwitchCheckDefault")
WebElement clickchckbox;

@FindBy(xpath="//input[@type='submit'and @value='REGISTER' ]")
WebElement Register;
@FindBy(xpath="//h6[contains(text(),' Corporate Membership ')]")
WebElement Register1;
public CorporateMembershipForm(WebDriver driver){

        // TODO Auto-generated constructor stub
        this.driver=driver;
        PageFactory.initElements(driver, this);
    }
public void clickMembership() throws InterruptedException
{
	
	Actions builder=new Actions(driver);
	builder.moveToElement(corpform).build().perform();
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
	wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//h6[contains(text(),' Corporate Membership ')]")));

		
//	wait.until(ExpectedConditions.waitForElementToBePresent
//(Register1));
corpfound.click();
}
	public void CorpMembForm() throws InterruptedException
	{
		Thread.sleep(1000);
		corpform.click();

	}
	public void CorpMembFound() throws InterruptedException
	{
		Thread.sleep(1000);
	
		corpfound.click();

	}
	public void CorpMembRegHere()
	{
		reghere.click();

	}
	public void scrollpage()
    {
        JavascriptExecutor js=(JavascriptExecutor)driver;
        js.executeScript("window.scrollBy(40,400)");

    }
	public void CorpMembRegName(String Name)
	{
		name.sendKeys("name");
	}
	public void CorpMembRegAdd(String Add)
	{
		add.clear();
		add.sendKeys("Add");

	}
	public void CorpMembRegHead(String Head)
	{
		head.clear();
		head.sendKeys("Head");

	}
	public void CorpMembRegNature(String Nature)
	{
		nature.clear();
		nature.sendKeys("Nature");

	}

	public void CorpMembRegwebsite(String Web)
	{
		web.clear();
		web.sendKeys("Web");

	}
	public void CorpMembRegCompany()
	{
		//WebElement toc=driver.findElement(By.xpath("//select[@formcontrolname='typeof']"));
		
		//toc.click();
		//Thread.sleep(500);
		Select company=new Select(driver.findElement(By.xpath("//select[@formcontrolname='typeof']")));
		company.selectByIndex(1);
		/*List<WebElement> list=option.getOptions();
		System.out.println("List");
		for(WebElement ele :list)
		{
			option.selectByVisibleText(ele.getAccessibleName());
		}*/
		}
	public void CINNumber(String CIN) throws Exception                                          //To set Corporate Identify Number
	{
	cin.clear();
	cin.sendKeys(CIN);
	Thread.sleep(300);
	}
	public void GSTNumber(String GST) throws InterruptedException
	{                                                                                      //To set up GST
	gst.clear();
	gst.sendKeys(GST);
	Thread.sleep(500);
	}
	// Point Of Contact.....................................................
	
	public void setPocName(String POCName) throws Exception
	{
	 Pocname.clear();
	 Pocname.sendKeys(POCName);
	 Thread.sleep(300);
	}
	public void setPocMobileNum(String MobNum)
	{
	 mobnum.clear();
	 mobnum.sendKeys(MobNum);
	}
	public void setPocTechnicalskill(String TechSkill)
	{
	 techskill.clear();
	 techskill.sendKeys(TechSkill);
	}
	public void setPocEmail(String EMAIL)
	{
	 email.clear();
	 email.sendKeys(EMAIL);
	}
	public void setPocEmployeeCount(String EmpCount)
	{
	 empcount.clear();
	 empcount.sendKeys(EmpCount);
	}
	public void collaborate() throws InterruptedException 
	{
		Thread.sleep(1000);
		collaborate.click();
        Fresherhiring.click();
		Thread.sleep(1000);
	 }
	 
	public void setNpp() throws InterruptedException
	{
		
		 Select patents = new Select(driver.findElement(By.xpath("//select[@formcontrolname='patents']")));
	     if (patents.isMultiple())
	       {
	         patents.selectByIndex(3);
	         patents.selectByValue("1: 1-10");
	       }
	     else
	       {
	         System.out.println("Multiple selection is not possible");
	       }
	     Thread.sleep(1000);
	     patents.selectByValue("1: 1-10");
	     Thread.sleep(1000);
	     Select companytype2 = new Select(driver.findElement(By.xpath("//select[@formcontrolname='patents']")));
	     companytype2.selectByIndex(2);
		
	}
	public void setPocAVGHiring() throws InterruptedException
	{
		 Select hire = new Select(driver.findElement(By.xpath("//select[@formcontrolname='hire']")));
	        if (hire.isMultiple())
	        {
	            hire.selectByIndex(3);
	            hire.selectByValue("4: 31-40");
	        }
	        else
	        {
	            System.out.println("Multiple selection is not possible");
	        }
	        Thread.sleep(1000);
	        hire.selectByValue("2: 11-20");
	        Thread.sleep(1000);
	        Select companytype2 = new Select(driver.findElement(By.xpath("//select[@formcontrolname='hire']")));
	        companytype2.selectByIndex(5);
		
	}
	
	public void Details(String details) throws InterruptedException
	{
	activitydetails.clear();
	activitydetails.sendKeys(details);
	Thread.sleep(300);
	}
	
	public void clickcheckbox()
    {
        //WebElement clickchckbox=driver.findElement(By.cssSelector(""));
        if(clickchckbox.isSelected())
        {
            System.out.println("ALready selected");
        }
        else
        {
            clickchckbox.click();
        }
    }
	public void clickRegister() throws InterruptedException
	{
		Thread.sleep(300);
		Register.click();
	}
	}
	
	
	
	
	
	
	
	

