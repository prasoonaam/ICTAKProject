package ictak;

import org.testng.annotations.Test;

import web.ictak.pages.LoginCorporateMembership;
import web.ictak.pages.LoginPartnership;

public class TestClassCorpMemb extends TestBase{
	LoginCorporateMembership objlcm=null;

	@Test
	public void logincorporatemembership() throws InterruptedException 
	{
		objlcm.Logincorporate();
		objlcm.Corporatedownload();
		
	}
}
