package ictak;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import web.ictak.pages.CorporateMembershipForm;

public class TestClassCorpmembform extends TestBase{
	CorporateMembershipForm objc=null;
	@Test
	public void corpmemb() throws InterruptedException
	{	
		objc=new CorporateMembershipForm(driver);
		objc.CorpMembForm();
		objc.CorpMembFound();
		objc.CorpMembRegHere();
		objc.scrollpage();
	}
	public void CorpMembRegName() throws InterruptedException{

//	String actualString = driver.findElement(By.xpath("//input[@type='text'and@name='name']")).getText();
//	assertTrue(actualString.contains("name"));
		objc.CorpMembRegName("name");
	Assert.assertEquals("Expected Text",driver.findElement(By.xpath("//input[@type='text'and@name='name']")).getText());
}
}